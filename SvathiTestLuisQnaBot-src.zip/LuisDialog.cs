using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
//using bot_luis_qna.Log;
using CardsBot;

namespace bot_luis_qna.Dialogs
{

   [LuisModel("fb168e36-d3a3-411d-9b30-5645657dc142","1c2ff22856c242d5b0d33ed731fb421f", LuisApiVersion.V2,"westus.api.cognitive.microsoft.com")]
      //luis id for svComparePhone3
   [Serializable]
    public class LuisDialog : LuisDialog<object>
    {   
        private const string EntityPhone1 = "google pixel";
        private const string EntityPhone2 = "iphone8";
        private const string EntityPhone3 = "oneplus5";
        private static string kb1="eef8190e-b8f1-49e8-bffe-826091260d33";
        private static string sk1= "729c26699d8946c8bbf19df80b0e6340";
        private static string kb2="d009cf67-e042-402b-baf5-c3973e1aa4f2";
        private static string sk2= "729c26699d8946c8bbf19df80b0e6340";
        private static string kb3="d028da64-0a96-47e0-ab36-d9255d40dcbe";
        private static string sk3="729c26699d8946c8bbf19df80b0e634";        
        EntityRecommendation GooglePixelRecommendation;
        EntityRecommendation Iphone8Recommendation;
        EntityRecommendation Oneplus5Recommendation;
        
        EntityRecommendation QuestionEntityRecommendation;
 //     EntityRecommendation PhoneEntityRecommendation;
        EntityRecommendation SpecsEntityRecommendation;
          
        [LuisIntent("qna_redirect3")]
        public async Task qna_redirect(IDialogContext context, LuisResult result)
        {
            string message = "qna_redirect3 Intent Detected";
            await context.PostAsync(message);
            string Detections = "" ;
            
            //Show all Entities in the utterance
            for(int i =0;i<result.Entities.Count;i++)
            {
                Detections+= i.ToString()+". Entity: " + result.Entities[i].Entity + " ; Type: "+result.Entities[i].Type +"\n" ;
                Detections = Detections.Replace("\n",System.Environment.NewLine);
            } 
           await context.PostAsync(Detections); 
           
           //Find Entity=Phone {}
           ////////////////Find Entity=Question and Specs
             if(result.TryFindEntity("Question_Type", out QuestionEntityRecommendation))
              {
                     //QuestionEntityRecommendation.Type = "Question";
                    // await context.PostAsync(QuestionEntityRecommendation.Entity);
              }
 ///////////////////////////////////////////////////Hierarchy type Question
              //  if(result.TryFindEntity("Question::how is", out QuestionEntityRecommendation))
              //  {
                //     //  QuestionEntityRecommendation.Type = "Question";
                //    //  await context.PostAsync(QuestionEntityRecommendation.Entity);
              //  }
              
              //  else if (result.TryFindEntity("Question::when", out QuestionEntityRecommendation))
              //  {
                //     //  QuestionEntityRecommendation.Type = "Question";
                //    // await context.PostAsync(QuestionEntityRecommendation.Entity);
              //  }
              //  //await context.PostAsync("Line 74 Exec");
              //  else if (result.TryFindEntity("Question::what", out QuestionEntityRecommendation))
              //  {
                //     //  QuestionEntityRecommendation.Type = "Question";
                //     //  await context.PostAsync(QuestionEntityRecommendation.Entity);
              //  }
              //  //await context.PostAsync("Line 80 Exec");
              //  else if (result.TryFindEntity("Question::which", out QuestionEntityRecommendation))
              // 
                //     //  QuestionEntityRecommendation.Type = "Question";
                //     //await context.PostAsync(QuestionEntityRecommendation.Entity);
              //  }
/////////////////////////////////////////////////////////
              
              if (result.TryFindEntity("Specs", out SpecsEntityRecommendation))
              {
                  //  SpecsEntityRecommendation.Type = "Specs";
                   //await context.PostAsync(SpecsEntityRecommendation.Entity);
              }
              
              
              /////////////////Reconstruct Q to redirect to Qna
              //string ReconstructedQuestion= SpecsEntityRecommendation.Entity ;
 
              await context.PostAsync("Reconstructed Q: "+SpecsEntityRecommendation.Entity);
             
             //QNA SERVICE REDIRECT 
             if (result.TryFindEntity("Phone_Type::GooglePixel", out GooglePixelRecommendation))
             {
                
                // await context.PostAsync("The Entity is:" +GooglePixelRecommendation.Entity);/// entity=google pixel return
                 //await context.PostAsync("The Type is:" +GooglePixelRecommendation.Type);/// type=phone return
                await context.PostAsync("Ans from Qna serice:SvGooglePixel");
                Dialogs.QnADialog qna = new Dialogs.QnADialog(kb1,sk1);
                
                if (!qna.TryQuery(SpecsEntityRecommendation.Entity, out message)){
                    message = $"Sorry, I do not know'{SpecsEntityRecommendation.Entity}'";
                }
                
                await context.PostAsync(message);
              }
             
              else if (result.TryFindEntity("Phone_Type::Iphone8", out Iphone8Recommendation))
              {
                  //QuestionEntityRecommendation.Type = "Question";
                  //await context.PostAsync("The Entity is:" +GooglePixelXLRecommendation.Entity);
                  //await context.PostAsync("The Type is:" +GooglePixelXLRecommendation.Type);
            
                await context.PostAsync("Ans from Qna serice:SvIphone8");
                Dialogs.QnADialog qna = new Dialogs.QnADialog(kb2,sk2);
                              
               if (!qna.TryQuery(SpecsEntityRecommendation.Entity, out message)){
                    message = $"Sorry, I do not know'{SpecsEntityRecommendation.Entity}'";
              }
               await context.PostAsync(message);
            } 
             else if (result.TryFindEntity("Phone_Type::OnePlus5", out Oneplus5Recommendation))
             {
                
                 // await context.PostAsync("The Entity is:" +GooglePixelRecommendation.Entity);/// entity=google pixel return
                 //await context.PostAsync("The Type is:" +GooglePixelRecommendation.Type);/// type=phone return
                await context.PostAsync("Ans from Qna serice:SvOnePlus5");
                Dialogs.QnADialog qna = new Dialogs.QnADialog(kb3,sk3);
                
                if (!qna.TryQuery(SpecsEntityRecommendation.Entity, out message)){
                    message = $"Sorry, I do not know'{SpecsEntityRecommendation.Entity}'";
                }
                
                await context.PostAsync(message);
           }
           else 
            { 
                await context.PostAsync("No ans found in Qna database");
             }
            
            
            context.Done(1);    // Go back to Root
        }
       
        [LuisIntent("")]
        [LuisIntent("None")]
        public async Task None(IDialogContext context, LuisResult result)
         { 
            
            string message = $"Sorry, I do not know'{result.Query}'";

            await context.PostAsync("Please ask a question of form <Question type-Specification-Phone Model>");
            
                
            await context.PostAsync(message);
            
            context.Done(1);    // Go back to Root
        }
    }
}
           