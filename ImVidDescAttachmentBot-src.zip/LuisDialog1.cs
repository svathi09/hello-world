using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
//using bot_luis_qna.Log;
using CardsBot;

namespace bot_luis_qna.Dialogs
{

   [LuisModel("cf63192b-5c5a-4ea2-9485-40e2109eedc3","1c2ff22856c242d5b0d33ed731fb421f", LuisApiVersion.V2,"westus.api.cognitive.microsoft.com")]
      //luis id for SvathiTask1  
   [Serializable]
    public class LuisDialog : LuisDialog<object>
    {   
        private const string Description1 = "Description of Google Pixel";
        private const string Image1 = "Image of Google Pixel";
        private const string Video1 = "Video of Google Pixel";
   
        EntityRecommendation GooglePixelRecommendation;
        EntityRecommendation Iphone8Recommendation;
        EntityRecommendation OnePlus5Recommendation;
        
        //EntityRecommendation Question_typeEntityRecommendation;
       // EntityRecommendation Mobile_NameEntityRecommendation;
          
        [LuisIntent("MobileDescription")]
        public async Task MobileDescription(IDialogContext context, LuisResult result)
        {
            string message1 = "MobileDescription Intent Detected";
            await context.PostAsync(message1);
            string Detections = "" ;
            
            //Show all Entities in the utterance-debug
            for(int i =0; i<result.Entities.Count;i++)
            {
                Detections+= i.ToString()+". Entity: " + result.Entities[i].Entity + "  ;  Type: "+result.Entities[i].Type + "\n" ;
                Detections = Detections.Replace("\n",System.Environment.NewLine);
            } 
           await context.PostAsync(Detections); 
           
           //Find Entity=Question and Phone
            //  if(result.TryFindEntity("Question_type", out Question_typeEntityRecommendation))
            //    {
            //           //QuestionEntityRecommendation.Type = "Question";
            //          //await context.PostAsync(Question_typeEntityRecommendation.Entity);
            //    }
              
            //  Reconstruct Q to redirect to Qna
            //  string ReconstructedQuestion= SpecsEntityRecommendation.Entity ;
            //  await context.PostAsync("Reconstructed Q (Phone found): "+Mobile_NameEntityRecommendation.Entity);


            //Ans for each phone
            if (result.TryFindEntity("Mobile_Name::GooglePixel", out GooglePixelRecommendation))  
             {
                //await context.PostAsync("The Type is:" +GooglePixelRecommendation.Type);/// type=phone return
                
                //1 describe
                await context.PostAsync("You chose Google Pixel");
                await context.PostAsync("1.Image 2.Video 3.Description");
                
                ////ADD PROMPT BUTTON HERE
               /////// Dialogs.RootDialog instance= new Dialog.RootDialog();
               //////// context.Wait(instance.option1());
                if(Description1)
                {
                    await context.PostAsync("Google Pixel Android smartphone. Announced Oct 2016. Features 5.0″ AMOLED display, Snapdragon 821 chipset, 12.3 MP primary camera.");
                }
                else if(Image1)
                {
                    private static Attachment GetInternetAttachment()
                    {
                        return new Attachment
                           { 
                            Name = "Screenshot-2017-03-06-at-00.37.39.png",
                            ContentType = "image/png",
                            ContentUrl = "https://blogs-images.forbes.com/gordonkelly/files/2017/03/Screenshot-2017-03-06-at-00.37.39.png"
                        };
                    }
                }
                else (Video1)
                {
                    private static Attachment GetInternetAttachment()
                    {
                        return new Attachment
                           { 
                            Name = "Screenshot-2017-03-06-at-00.37.39.png",
                            ContentType = "image/png",
                            ContentUrl = "https://blogs-images.forbes.com/gordonkelly/files/2017/03/Screenshot-2017-03-06-at-00.37.39.png"
                        };
                    }
                }
               
                //  //2 image and video
                //  var message = context.MakeMessage();
                //  var attachment = CardsDialog.GetSelectedCard("GooglePixel"); 
                //  message.Attachments.Add(attachment);
                //  await context.PostAsync(message);

                //context.Wait(Option1);////////
                context.Done(1); 
             }
            //  else if (result.TryFindEntity("Mobile_Name::Iphone8", out Iphone8Recommendation))
            //   {
            //      //1 describe
            //      await context.PostAsync("This is Iphone8");
            //      //2 image and video
            //      var message = context.MakeMessage();
            //      var attachment = CardsDialog.GetSelectedCard("Iphone8"); 
            //      message.Attachments.Add(attachment);
            //      await context.PostAsync(message);

            //      //context.Wait(Option1);//////////
            //      context.Done(1); 
            //   }
            //   else if (result.TryFindEntity("Mobile_Name::OnePlus5", out OnePlus5Recommendation))
            //   {
            //      //1 describe
            //      await context.PostAsync("This is OnePlus5");
            //      //2 image and video
            //      var message = context.MakeMessage();
            //      var attachment = CardsDialog.GetSelectedCard("OnePlus5"); 
            //      message.Attachments.Add(attachment);
            //      await context.PostAsync(message);

            //      //context.Wait(Option1);///////////
            //      context.Done(1); 
            //   }
            else 
            { 
                await context.PostAsync("No ans found in database");
             }
            
            
            context.Done(1);    // Go back to Root
        }


        [LuisIntent("")]
        [LuisIntent("None")]
        public async Task None(IDialogContext context, LuisResult result)
         { 
            
            string message = $"Sorry, I do not know'{result.Query}'";

            await context.PostAsync("Please ask a question of form <Question type-Phone Model>");
            
                
            await context.PostAsync(message);
            
            context.Done(1);    // Go back to Root
        }



        //  private const string Continue1 = "Do you want to Continue?";
        //  private const string Quit1 = "Quit";

        //  private async Task Option1(IDialogContext context, IAwaitable<IMessageActivity> result)
        //      {
        //          PromptDialog.Choice(
        //              context, 
        //              this.AfterChoiceSelected, 
        //              new[] { Continue1, Quit1}, 
        //              "What do you want to do today?", 
        //              "I am sorry but I didn't understand that. I need you to select one of the options below",
        //              attempts: 2);
        //      }
        //  private async Task AfterChoiceSelected(IDialogContext context, IAwaitable<string> result)
        //          {
                    
                
        //                  if(Continue1)
        //                  {
        //                          await context.PostAsync("ask about another flagship phone");
        //                          //context.Wait(MessageReceivedAsync);
        //                  }        
                                
                                                
        //                  else if (Quit1)
        //                  {
        //                          await context.PostAsync("Thank you");
        //                          //context.Wait(MessageReceivedAsync);
                            
        //                  }
        //                  else 
        //                  {
        //                      await context.PostAsync("!!");
        //                  }                  
                   
        //           }


     }
   
}
           