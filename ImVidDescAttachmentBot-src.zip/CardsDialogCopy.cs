namespace CardsBot
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using System.Web;
    using Microsoft.Bot.Builder.Dialogs;
    using Microsoft.Bot.Connector;

    [Serializable]
    public class CardsDialog : IDialog<object>
    {
        private const string HeroCard = "Hero card";
        //  private const string GooglePixel = "Google Pixel";
        //  private const string Iphone8 = "Iphone 8";
        //  private const string OnePlus5 = "OnePlus 5";
        private const string ThumbnailCard = "Google Pixel";//GOOGLE PIXEL
        private const string ReceiptCard = "Iphone 8";//IPHOME8
        private const string SigninCard = "One Plus 5";//ONEPLUS5
        private const string AnimationCard = "Animation card";
        private const string VideoCard = "Video card";
        private const string AudioCard = "Audio card";

        private IEnumerable<string> options = new List<string> {HeroCard,ThumbnailCard,ReceiptCard, SigninCard, AnimationCard, VideoCard, AudioCard };

        public async Task StartAsync(IDialogContext context)
        {
            context.Wait(this.MessageReceivedAsync);/// 
        }

        public async virtual Task MessageReceivedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
           var message = await result;

           PromptDialog.Choice<string>(
               context,
               this.DisplaySelectedCard,
               this.options,
               "What card would like to test?",
               "Ooops, what you wrote is not a valid option, please try again",
               3,
               PromptStyle.PerLine);
        }

        public async Task DisplaySelectedCard(IDialogContext context, IAwaitable<string> result)
        {
            var selectedCard = await result;

            var message = context.MakeMessage();

            var attachment = GetSelectedCard(selectedCard);
            message.Attachments.Add(attachment);

            await context.PostAsync(message);

            //context.Wait(MessageReceivedAsync);
        }

        public static Attachment GetSelectedCard(string selectedCard)
        {
            switch (selectedCard)
            {
                case HeroCard:
                    return GetHeroCard();
                //  case GooglePixel:
                //      return GetGooglePixelImageVideo();  

                //  case Iphone8:
                //      return GetIphone8ImageVideo();

                //  case OnePlus5:
                //      return GetOnePlus5ImageVideo(); 
                 
                case ThumbnailCard:
                    return GetThumbnailCard();
                case ReceiptCard:
                    return GetReceiptCard();
                case SigninCard:
                    return GetSigninCard();
                case AnimationCard:
                    return GetAnimationCard();
                case VideoCard:
                    return GetVideoCard();
                case AudioCard:
                    return GetAudioCard();

                default:
                    return GetHeroCard();
            }
        }

        private static Attachment GetHeroCard()
        {
            var heroCard = new HeroCard
            {
                Title = "BotFramework Hero Card",
                Subtitle = "Your bots — wherever your users are talking",
                Text = "Build and connect intelligent bots to interact with your users naturally wherever they are, from text/sms to Skype, Slack, Office 365 mail and other popular services.",
                Images = new List<CardImage> { new CardImage("https://sec.ch9.ms/ch9/7ff5/e07cfef0-aa3b-40bb-9baa-7c9ef8ff7ff5/buildreactionbotframework_960.jpg") },
                Buttons = new List<CardAction> { new CardAction(ActionTypes.OpenUrl, "Get Started", value: "https://docs.microsoft.com/bot-framework") }
            };

            return heroCard.ToAttachment();
        }


//////////////////////////////////////
        //  private static Attachment GetGooglePixelImageVideo()
        //    {
            
        //    }
        
/////////////////////////////
        //  private static Attachment GetIphone8ImageVideo()
        //    {
            
        //    }
        ///////////////////////////////////////////////
        //  private static Attachment GetOnePlus5ImageVideo()
        //    {
            
        //    }
        

        //////////////////////////////////////////////////////////////////////////////
        private static Attachment GetThumbnailCard()
        {   ////////////GOOGLE PIXEL
            var ImageVideoCard = new ThumbnailCard
            {
                Title = "BotFramework Google Pixel",
                Subtitle = "by Google",
                Text = "Google Pixel Android smartphone. Announced Oct 2016. Features 5.0″ AMOLED display, Snapdragon 821 chipset, 12.3 MP primary camera.",
                Image = new ThumbnailUrl
                {
                    Url = "https://www.google.co.in/search?q=google+pixel&rlz=1C1GGRV_enIN767IN767&source=lnms&tbm=isch&sa=X&ved=0ahUKEwj7prew6YjYAhXIXhQKHeUfCIMQ_AUICygC&biw=1366&bih=613#imgrc=M_kdrQcWV-N_oM:"
                },
                Media = new List<MediaUrl>
                {
                    new MediaUrl()
                    {
                        Url = "//players.brightcove.net/1564549378/default_default/index.html?videoId=5623414348001"  
                    }
                },
                Buttons = new List<CardAction>
                {
                    new CardAction()
                    {
                        Title = "Learn More",
                        Type = ActionTypes.OpenUrl,
                        Value = "https://www.gsmarena.com/google_pixel-8346.php"
                    }
                }
            };
            return ImageVideoCard.ToAttachment();
        }

        private static Attachment GetReceiptCard()
        {  ///////////////////////////IPHONE8
            var ImageVideoCard = new ReceiptCard 
            {
                Title = "BotFramework Iphone8",
                //Subtitle = "by Apple",
                //Text = "Apple iPhone 8 smartphone. Announced Sep 2017. Features 4.7″ LED-backlit IPS LCD display, Apple A11 Bionic chipset, 12 MP primary camera",
                //  Image = new ThumbnailUrl
                //  {
                //      Url = "https://www.google.co.in/search?q=iphone+8&rlz=1C1GGRV_enIN767IN767&source=lnms&tbm=isch&sa=X&ved=0ahUKEwjn7KKojInYAhUC0RQKHXzDBNMQ_AUICigB&biw=1366&bih=613#imgrc=8Hb3G9CtAIXWRM:"
                //  },
                //  Media = new List<MediaUrl>
                //  {
                //      new MediaUrl()
                //      {
                //          Url = "http://players.brightcove.net/1564549378/default_default/index.html?videoId=5591049885001"  
                //      }
                //  },
                Buttons = new List<CardAction>
                {
                    new CardAction()
                    {
                        Title = "Learn More",
                        Type = ActionTypes.OpenUrl,
                        Value = "https://www.gsmarena.com/apple_iphone_8-8573.php"
                    }
                }
            };
            return ImageVideoCard.ToAttachment();
        }

       private static Attachment GetSigninCard()
        {//////////////////////////ONEPLUS5
           var ImageVideoCard = new SigninCard
            {
                //Title = "BotFramework OnePlus5",
               // Subtitle = "By OPPO",
                Text = "The OnePlus 5 was unveiled on 20 June 2017. It launched with a Qualcomm Snapdragon 835, a dual-lens camera setup, up to 8 GB RAM, and up to 128 GB of storage. It was released in two colors: Midnight Black and Slate Gray.",
                //  Image = new ThumbnailUrl
                //  {
                //      Url = "https://www.google.co.in/search?q=google+pixel&rlz=1C1GGRV_enIN767IN767&source=lnms&tbm=isch&sa=X&ved=0ahUKEwj7prew6YjYAhXIXhQKHeUfCIMQ_AUICygC&biw=1366&bih=613#imgrc=M_kdrQcWV-N_oM:"
                //  },
                //  Media = new List<MediaUrl>
                //  {
                //      new MediaUrl()
                //      {
                //          Url = "//players.brightcove.net/1564549378/default_default/index.html?videoId=5477550083001"  
                //      }
                //  },
                Buttons = new List<CardAction>
                {
                    new CardAction()
                    {
                        Title = "Learn More",
                        Type = ActionTypes.OpenUrl,
                        Value = "https://www.gsmarena.com/oneplus_5-8647.php"
                    }
                }
            };
            return ImageVideoCard.ToAttachment();
        }

        private static Attachment GetAnimationCard()
        {
            var animationCard = new AnimationCard
            {
                Title = "Microsoft Bot Framework",
                Subtitle = "Animation Card",
                Image = new ThumbnailUrl
                {
                    Url = "https://docs.microsoft.com/en-us/bot-framework/media/how-it-works/architecture-resize.png"
                },
                Media = new List<MediaUrl>
                {
                    new MediaUrl()
                    {
                        Url = "http://i.giphy.com/Ki55RUbOV5njy.gif"
                    }
                }
            };

            return animationCard.ToAttachment();
        }

        private static Attachment GetVideoCard()
        {
            var videoCard = new VideoCard
            {
                Title = "Big Buck Bunny",
                Subtitle = "by the Blender Institute",
                Text = "Big Buck Bunny (code-named Peach) is a short computer-animated comedy film by the Blender Institute, part of the Blender Foundation. Like the foundation's previous film Elephants Dream, the film was made using Blender, a free software application for animation made by the same foundation. It was released as an open-source film under Creative Commons License Attribution 3.0.",
                Image = new ThumbnailUrl
                {
                    Url = "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Big_buck_bunny_poster_big.jpg/220px-Big_buck_bunny_poster_big.jpg"
                },
                Media = new List<MediaUrl>
                {
                    new MediaUrl()
                    {
                        Url = "http://download.blender.org/peach/bigbuckbunny_movies/BigBuckBunny_320x180.mp4"  
                    }
                },
                Buttons = new List<CardAction>
                {
                    new CardAction()
                    {
                        Title = "Learn More",
                        Type = ActionTypes.OpenUrl,
                        Value = "https://peach.blender.org/"
                    }
                }
            };

            return videoCard.ToAttachment();
        }

        private static Attachment GetAudioCard()
        {
            var audioCard = new AudioCard
            {
                Title = "I am your father",
                Subtitle = "Star Wars: Episode V - The Empire Strikes Back",
                Text = "The Empire Strikes Back (also known as Star Wars: Episode V – The Empire Strikes Back) is a 1980 American epic space opera film directed by Irvin Kershner. Leigh Brackett and Lawrence Kasdan wrote the screenplay, with George Lucas writing the film's story and serving as executive producer. The second installment in the original Star Wars trilogy, it was produced by Gary Kurtz for Lucasfilm Ltd. and stars Mark Hamill, Harrison Ford, Carrie Fisher, Billy Dee Williams, Anthony Daniels, David Prowse, Kenny Baker, Peter Mayhew and Frank Oz.",
                Image = new ThumbnailUrl
                {
                    Url = "https://upload.wikimedia.org/wikipedia/en/3/3c/SW_-_Empire_Strikes_Back.jpg"
                },
                Media = new List<MediaUrl>
                {
                    new MediaUrl()
                    {
                        Url = "http://www.wavlist.com/movies/004/father.wav"
                    }
                },
                Buttons = new List<CardAction>
                {
                    new CardAction()
                    {
                        Title = "Read More",
                        Type = ActionTypes.OpenUrl,
                        Value = "https://en.wikipedia.org/wiki/The_Empire_Strikes_Back"
                    }
                }
            };

            return audioCard.ToAttachment();
        }
    }
}