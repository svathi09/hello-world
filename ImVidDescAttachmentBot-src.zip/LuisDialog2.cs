using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
//using bot_luis_qna.Log;
using CardsBot;
namespace bot_luis_qna.Dialogs
{

   [LuisModel("cf63192b-5c5a-4ea2-9485-40e2109eedc3","1c2ff22856c242d5b0d33ed731fb421f", LuisApiVersion.V2,"westus.api.cognitive.microsoft.com")]
      //luis id for SvathiTask1  
   [Serializable]
    public class LuisDialog : LuisDialog<object>
    {   
        private const string Description1 = "Description of Google Pixel";
        private const string Image1 = "Image of Google Pixel";
        private const string Video1 = "Video of Google Pixel";
   
        EntityRecommendation GooglePixelRecommendation;
        EntityRecommendation Iphone8Recommendation;
        EntityRecommendation OnePlus5Recommendation;
        
        //EntityRecommendation Question_typeEntityRecommendation;
       // EntityRecommendation Mobile_NameEntityRecommendation;
       //////////////////////////////////////////////////////////////
       private readonly IDictionary<string, string> options = new Dictionary<string, string>
        {
            { "1", ShowInlineAttachment },
            { "2", ShowUploadedAttachment },
            { "3", ShowInternetAttachment }///
        };
        Attachment attachment = null;
        private static GetInternetAttachment() 
               {                        /////////////////////////////
                 var ShowInternetAttachment= new ShowInternetAttachment
            
                    {
                        Name = "BotFrameworkOverview.png",
                        ContentType = "image/png",
                        ContentUrl = "https://cdn2.gsmarena.com/vv/pics/google/google-pixel-02.jpg"
                    };
                return ShowInternetAttachment;
              }
       
       
       
       
          
        [LuisIntent("MobileDescription")]
        public async Task MobileDescription(IDialogContext context, LuisResult result)
        {
            string message1 = "MobileDescription Intent Detected";
            await context.PostAsync(message1);
            string Detections = "" ;
            
            //Show all Entities in the utterance-debug
            for(int i =0; i<result.Entities.Count;i++)
            {
                Detections+= i.ToString()+". Entity: " + result.Entities[i].Entity + "  ;  Type: "+result.Entities[i].Type + "\n" ;
                Detections = Detections.Replace("\n",System.Environment.NewLine);
            } 
           await context.PostAsync(Detections); 
           
           
           if (result.TryFindEntity("Mobile_Name::GooglePixel", out GooglePixelRecommendation))  
            {
                //await context.PostAsync("The Type is:" +GooglePixelRecommendation.Type);/// type=phone return
                
                //1 describe
                await context.PostAsync("You chose Google Pixel");
                await context.PostAsync("1.Description 2.Video 3.Image");//enter 3
                GetInternetAttachment() ;
             
                
               // Dialogs.SendAttachmentDialog obj1 = new Dialogs.SendAttachmentDialog();
               // Attachment.SendAttachmentDialog obj1 = new Attachment.SendAttachmentDialog();
                // obj1.GetInternetAttachment();
            }
          else 
            { 
                await context.PostAsync("No ans found in database");
             }
            
            
            context.Done(1);    // Go back to Root
        }  
        [LuisIntent("")]
        [LuisIntent("None")]
        public async Task None(IDialogContext context, LuisResult result)
         { 
            
            string message = $"Sorry, I do not know'{result.Query}'";

            await context.PostAsync("Please ask a question of form <Question type-Phone Model>");
            
                
            await context.PostAsync(message);
            
            context.Done(1);    // Go back to Root
        }
      
    }
}
